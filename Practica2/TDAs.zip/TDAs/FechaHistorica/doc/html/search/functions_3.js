var searchData=
[
  ['main',['main',['../fechahistorica__exe_8cpp.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'fechahistorica_exe.cpp']]],
  ['mostrarsucesos',['mostrarSucesos',['../classFechaHistorica.html#a5c1a1d6cf44b8a1414d6d682479e377a',1,'FechaHistorica']]]
];
