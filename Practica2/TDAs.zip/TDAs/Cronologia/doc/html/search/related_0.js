var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classCronologia.html#a5a590e2ec95cc4489c3de5b03e2cac4c',1,'Cronologia::operator&lt;&lt;()'],['../classFechaHistorica.html#ae7ffc75da1b9b42da839968d57c0dc9c',1,'FechaHistorica::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classCronologia.html#a6fa0f1131309b1cee355b9d8297ea33d',1,'Cronologia::operator&gt;&gt;()'],['../classFechaHistorica.html#a25a93d162aadd3c52aa1f3d1831e3d75',1,'FechaHistorica::operator&gt;&gt;()']]]
];
