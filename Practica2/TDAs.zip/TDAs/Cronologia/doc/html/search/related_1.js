var searchData=
[
  ['unir',['unir',['../classCronologia.html#a580622d3eaaa4c551dde62be88a4106e',1,'Cronologia']]]
];
