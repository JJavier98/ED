var searchData=
[
  ['get_5facontecimientos',['get_acontecimientos',['../classFechaHistorica.html#a469500ac9ec3ad7ae77cdd9f6b5b3cdc',1,'FechaHistorica']]]
];
