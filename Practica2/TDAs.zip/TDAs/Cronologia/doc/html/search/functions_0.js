var searchData=
[
  ['add',['add',['../classCronologia.html#a074d231653a08d759ddeb6e5788029f9',1,'Cronologia::add()'],['../classFechaHistorica.html#ad69f7b15d79d9329f03fc948b620b78f',1,'FechaHistorica::add()']]]
];
