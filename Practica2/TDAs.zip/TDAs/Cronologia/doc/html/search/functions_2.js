var searchData=
[
  ['cronologia',['Cronologia',['../classCronologia.html#ac0026b1919148f6cd6cf4ca4c357771e',1,'Cronologia::Cronologia()'],['../classCronologia.html#ada45af8cc8b3889186d0cd1da4a8d865',1,'Cronologia::Cronologia(const FechaHistorica &amp;f)'],['../classCronologia.html#a07d15a509e8f1681928547c297f9493e',1,'Cronologia::Cronologia(string fichero)'],['../classCronologia.html#a35694d459c7f2bc902b8db6abf13662d',1,'Cronologia::Cronologia(const Cronologia &amp;c)']]]
];
