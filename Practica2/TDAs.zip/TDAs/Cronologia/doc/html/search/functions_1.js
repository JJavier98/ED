var searchData=
[
  ['buscaanio',['buscaAnio',['../classCronologia.html#aab9a8231643b9d6bbe571f64c04cf1e1',1,'Cronologia']]],
  ['buscaanioborra',['buscaAnioBorra',['../classCronologia.html#a778115222477ac158102c9ed2f13dc02',1,'Cronologia']]],
  ['buscaaniomuestra',['buscaAnioMuestra',['../classCronologia.html#a61d069aa6c7bdac972796605a7d716c2',1,'Cronologia']]],
  ['buscapalabra',['buscaPalabra',['../classCronologia.html#a9dea9900b903e30a28333b146350aa47',1,'Cronologia']]],
  ['buscapalabraborra',['buscaPalabraBorra',['../classCronologia.html#a5326dafa3c78b064c6e461098e50882c',1,'Cronologia']]],
  ['buscapalabramuestra',['buscaPalabraMuestra',['../classCronologia.html#aae687de86ad56c86f30fb6908f51222b',1,'Cronologia']]]
];
