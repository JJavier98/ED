var searchData=
[
  ['fechahistorica',['FechaHistorica',['../classFechaHistorica.html#a35baa09e365240e567049a7e33a7c209',1,'FechaHistorica::FechaHistorica()'],['../classFechaHistorica.html#a81a9cdafd24a7e649f239754cc6d6317',1,'FechaHistorica::FechaHistorica(int anio, string sucesos)'],['../classFechaHistorica.html#a40a9c133a139d41bf84406e09022feaf',1,'FechaHistorica::FechaHistorica(const FechaHistorica &amp;f)']]]
];
